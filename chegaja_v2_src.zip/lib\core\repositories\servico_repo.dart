// lib/core/repositories/servico_repo.dart
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:chegaja_v2/core/models/servico.dart';

class ServicosRepo {
  // Referência para a coleção `servicos`
  static CollectionReference<Map<String, dynamic>> get _col =>
      FirebaseFirestore.instance.collection('servicos');

  /// Stream de serviços ATIVOS (isActive == true),
  /// já filtrados e ordenados pelo nome.
  static Stream<List<Servico>> streamServicosAtivos() {
    // ⚠️ IMPORTANTE (fix do “Home vazia”):
    // Antigamente fazíamos `.where('isActive' == true)`. Se o catálogo tiver
    // docs antigos sem o campo `isActive` (apenas `ativo`), a query devolve 0
    // resultados e a Home do cliente fica vazia.
    //
    // Como o catálogo é pequeno (~80 serviços), é seguro escutar a coleção toda
    // e filtrar no lado da app (com compatibilidade v1/v2 no modelo Servico).
    return _col.snapshots().map((snapshot) {
      final lista = snapshot.docs
          .map((doc) => Servico.fromMap(doc.data(), doc.id))
          .where((s) => s.isActive)
          .toList();

      lista.sort((a, b) => a.name.compareTo(b.name));
      return lista;
    });
  }

  /// Versão Future: obtém uma lista de serviços ativos uma única vez.
  static Future<List<Servico>> getServicosAtivosOnce() async {
    final snapshot = await _col.get();
    final lista = snapshot.docs
        .map((doc) => Servico.fromMap(doc.data(), doc.id))
        .where((s) => s.isActive)
        .toList();
    lista.sort((a, b) => a.name.compareTo(b.name));
    return lista;
  }

  /// NOVO: busca serviços ativos filtrando por modo
  /// (IMEDIATO / AGENDADO / POR_PROPOSTA).
  ///
  /// Esta função é usada no NovoPedidoScreen v2, onde chamamos:
  ///   ServicosRepo.buscarServicosAtivosPorModo(_modo)
    /// Busca todos os serviços ATIVOS (sem filtrar por modo).
  static Future<List<Servico>> buscarServicosAtivosTodos() async {
    final snapshot = await _col.get();
    final lista = snapshot.docs
        .map((doc) => Servico.fromMap(doc.data(), doc.id))
        .where((s) => s.isActive)
        .toList();
    lista.sort((a, b) => a.name.compareTo(b.name));
    return lista;
  }

static Future<List<Servico>> buscarServicosAtivosPorModo(String modo) async {
    // Mesma lógica: compatibilidade com docs antigos (mode/modo e isActive/ativo)
    final target = modo.toUpperCase().trim();
    final snapshot = await _col.get();
    final lista = snapshot.docs
        .map((doc) => Servico.fromMap(doc.data(), doc.id))
        .where((s) => s.isActive)
        .where((s) {
          if (target == 'IMEDIATO') {
            // compatibilidade: serviços antigos marcados como POR_PROPOSTA aparecem no IMEDIATO
            return s.mode == 'IMEDIATO' || s.mode == 'POR_PROPOSTA';
          }
          if (target == 'AGENDADO') {
            return s.mode == 'AGENDADO';
          }
          // fallback
          return s.mode == target;
        })
        .toList();
    lista.sort((a, b) => a.name.compareTo(b.name));
    return lista;
  }

  /// Busca um serviço pelo ID (ou devolve null se não existir).
  static Future<Servico?> getServicoById(String id) async {
    final doc = await _col.doc(id).get();
    if (!doc.exists) return null;

    final data = doc.data();
    if (data == null) return null;

    return Servico.fromMap(data, doc.id);
  }

  /// Cria ou atualiza um serviço (útil para seeds, painel admin, etc.).
  static Future<void> salvarServico(Servico servico) async {
    await _col.doc(servico.id).set(
          servico.toMap(includeCreatedAt: true),
          SetOptions(merge: true),
        );
  }
}
