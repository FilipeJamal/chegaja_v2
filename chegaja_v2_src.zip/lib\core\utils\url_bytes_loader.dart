export 'url_bytes_loader_stub.dart'
    if (dart.library.html) 'url_bytes_loader_web.dart';
