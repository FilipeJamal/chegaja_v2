// ignore_for_file: avoid_web_libraries_in_flutter, deprecated_member_use
// lib/core/services/perfil_foto_picker_web.dart
import 'dart:async';
import 'dart:html' as html;
import 'dart:typed_data';
import 'package:flutter/material.dart';

/// Picker para **Flutter Web** usando <input type="file">.
/// Não depende de plugin nenhum.
Future<Uint8List?> pickImageBytes(BuildContext context) async {
  final completer = Completer<Uint8List?>();

  try {
    final input = html.FileUploadInputElement()..accept = 'image/*';
    input.click();

    input.onChange.listen((event) {
      final file = input.files?.first;
      if (file == null) {
        completer.complete(null); // utilizador cancelou
        return;
      }

      final reader = html.FileReader();
      reader.readAsArrayBuffer(file);

      reader.onLoadEnd.listen((event) {
        final result = reader.result;
        if (result is Uint8List) {
          completer.complete(result);
        } else if (result is ByteBuffer) {
          completer.complete(result.asUint8List());
        } else {
          completer.completeError('Formato de dados desconhecido.');
        }
      });

      reader.onError.listen((event) {
        completer.completeError(reader.error ?? 'Erro ao ler ficheiro.');
      });
    });

    input.onError.listen((event) {
      completer.completeError('Erro ao selecionar ficheiro.');
    });
  } catch (e) {
    completer.completeError(e);
  }

  return completer.future;
}
